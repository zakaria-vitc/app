window._config = {
    cognito: {
        userPoolId: 'ap-south-1_fMkul0Fbi', 
        userPoolClientId: '539dfgrgg7onkeevjvisjb3v47', 
        region: 'ap-south-1' 
    },
    api: {
        invokeUrl: 'https://b8hr1whxef.execute-api.ap-south-1.amazonaws.com/prod',
    }
};
